from flask import Response
import json


class TokenResponse:

    @staticmethod
    def return_token(token_string):
        if not token_string:
            return Response(json.dumps({"status": "Token not generated"}), status=200)
        else:
            return Response(json.dumps({"Access Token": token_string}), status=201)
