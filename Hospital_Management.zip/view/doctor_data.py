import json


class DoctorReturnData:

    def doctor_modify(self, status):
        status_code = 200
        if status:
            response = json.dumps({"status": "Requested Attribute Modified"})
        else:
            response = json.dumps({"status": "requested Attribute Not Modified"})
            status_code = 304
        return_data = {'status':response, 'status code':status_code}
        return return_data



