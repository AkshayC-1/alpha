import json


class NurseReturnData:

    def nurse_modify(self, status):
        status_code = 200
        if status:
            response = json.dumps({"status": "Requested Attribute Modified"})
        else:
            response = json.dumps({"status": "requested Attribute Not Modified"})
            status_code = 304
        return_data = {'status': response, 'status code': status_code}
        return return_data

    def delete_ward(self, status):
        status_code = 200
        if status:
            response = json.dumps({"status": "Requested Attribute deleted"})
        else:
            response = json.dumps({"status": "requested Attribute Not deleted"})
            status_code = 404
        return_data = {'status': response, 'status code': status_code}
        return return_data


