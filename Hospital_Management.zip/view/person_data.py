import json
from flask import Response

class PersonReturnData:

    def new_user(self, status):
        status_code = 201
        if status:
            response = json.dumps({"status": "New User Added"})
        else:
            response = json.dumps({"status": "User Not Added"})
            status_code = 304
        return_data = {'status': response, 'status code': status_code}
        return return_data

    def delete_user(self,status):
        status_code = 200
        if status:
            response = json.dumps({"status": "Deleted the entry"})
        else:
            response = json.dumps({"status": "Delete operation not performed"})
            status_code = 404
        return_data = {'status': response, 'status code': status_code}
        return return_data

    def person_search(self, result, person_type):
        if result[person_type]:
            response = Response(json.dumps(result), status=200)
        else:
            response = Response(json.dumps({"status": "Entry Not Found"}), status=404)
        return response

