from model.db_doctor import DbDoctor
from person_service import PersonService
from query_constants import Query as constant
from logger.exception_logger import ExceptionLogger

class DoctorService:
    __instance = None

    def __init__(self):
        self.doctor_db_data = DbDoctor.get_db_doctor_instance()
        self.person_detail = PersonService.get_person_service_instance()

    @classmethod
    def get_doctor_service_instance(cls):
        if cls.__instance is None:
            cls.__instance = DoctorService()
        return cls.__instance

    def record_exists(self, search_result):
        return_status = True
        try:
            search_result[0]
        except:
            return_status = False
        return return_status

    def get_all_doctor(self):
        all_doctor_data = []
        doctor_result = self.doctor_db_data.get_info(constant.ALL_DOCTORS)
        for doctor_entry in doctor_result:
            person_result = self.person_detail.search_person_by_id(doctor_entry.personid)
            person_result["Specialization"] = doctor_entry.specialization
            all_doctor_data.append(person_result)
        return all_doctor_data

    def get_doctor_by_id(self,person_id):
        doctors_detail = {}
        staff_id = self.get_doctors_id(person_id)
        if staff_id:
            query = constant.DOCTOR_BY_ID % staff_id
            doctor_table_data = self.doctor_db_data.get_info(query)
            doctors_detail = self.person_detail.search_person_by_id(person_id)
            doctors_detail["Specialization"] = doctor_table_data[0].specialization
        return doctors_detail

    def get_doctors_name(self, staff_id):
        doctors_name = False
        query = constant.PERSON_ID_OF_DOCTOR % staff_id
        person_id = self.doctor_db_data.get_info(query)
        if self.record_exists(person_id):
            person_information = self.person_detail.search_person_by_id(person_id[0].personid)
            doctors_name = person_information["Name"]
        return doctors_name

    def get_doctors_id(self,person_id):
        query = constant.STAFF_ID_OF_DOCTOR % person_id
        doctor_search_result = self.doctor_db_data.get_info(query)
        if self.record_exists(doctor_search_result):
            staff_id = doctor_search_result[0].staffid
        else:
            staff_id = False
        return staff_id

    def add_new_doctor(self, doctors_details):
        person_type = 'd'
        add_status = False
        person_id = self.person_detail.add_new_person(doctors_details, person_type)
        if person_id:
            staff_id = "d"+str(person_id)
            try:
                query = constant.ADD_NEW_DOCTOR % (staff_id, person_id, doctors_details["specialization"])
            except Exception, e:
                ExceptionLogger.log_exception(e)
                self.person_detail.delete_person_by_id(person_id)
                return False
            add_status = self.doctor_db_data.set_info(query)
            if not add_status:
                self.person_detail.delete_person_by_id(person_id)
        return add_status

    def change_specialization(self, person_id, new_specialization):
        staff_id = self.get_doctors_id(person_id)
        if staff_id:
            query = constant.UPDATE_DOCTOR_SPECIALIZATION % (new_specialization,staff_id)
            modify_status = self.doctor_db_data.set_info(query)
        else:
            modify_status = False
        return modify_status

    def delete_doctor(self,person_id):
        staff_id = self.get_doctors_id(person_id)
        delete_status = True
        if not staff_id:
            delete_status = False
        else:
            query = constant.DELETE_DOCTOR % staff_id
            delete_status = self.doctor_db_data.set_info(query)
            delete_status = delete_status and self.person_detail.delete_person_by_id(person_id)
            delete_status = delete_status and self.delete_patient_treatement_by_doctor_id(staff_id)
        return delete_status

    def delete_patient_treatement_by_doctor_id(self, staff_id):
        delete_status =True
        query = constant.MAP_DOCTOR_TO_PATIENT % staff_id
        search_result = self.doctor_db_data.get_info(query)
        if self.record_exists(search_result):
            for data in search_result:
                query = constant.DELETE_PATIENT_TREATEMENT % (data.patientid, staff_id)
                delete_status = delete_status and self.doctor_db_data.set_info(query)
        return delete_status

