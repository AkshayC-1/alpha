from model.db_patient import DbPatient
from doctor_service import DoctorService
from person_service import PersonService
from ward_service import WardService
from query_constants import Query as Constant
from logger.exception_logger import ExceptionLogger


class PatientService:
    __instance = None

    def __init__(self):
        self.patient_db_data = DbPatient.get_db_patient_instance()
        self.person_detail = PersonService.get_person_service_instance()
        self.ward_details = WardService.get_ward_service_instance()
        self.doctor_details = DoctorService.get_doctor_service_instance()

    @classmethod
    def get_patient_service_instance(cls):
        if cls.__instance is None:
            cls.__instance = PatientService()
        return cls.__instance

    def get_patient_data(self):
        return self.get_all_patient()

    def record_exists(self, search_result):
        return_status = True
        try:
            search_result[0]
        except:
            return_status = False
        return return_status

    def get_patient_personal_detail(self, patient_information):
        person_result = self.person_detail.search_person_by_id(patient_information.personid)
        person_result["Disease"] = patient_information.disease
        person_result["Visited Date"] = str(patient_information.visiteddate)
        doctor_name = self.get_patients_doctor(patient_information.patientid)
        person_result["Doctor"] = doctor_name
        person_result["admitted room"] = self.ward_details.get_patient_room(patient_information.patientid)
        return person_result

    def get_all_patient(self):
        all_patient_data = []
        patient_result = self.patient_db_data.get_info(Constant.ALL_PATIENT)
        for patient_information in patient_result:
            patient_details = self.get_patient_personal_detail(patient_information)
            all_patient_data.append(patient_details)
        return all_patient_data

    def get_patient_id(self, person_id):
        query = Constant.GET_PATIENT_ID % person_id
        patient_search_result = self.patient_db_data.get_info(query)
        if self.record_exists(patient_search_result):
            patient_id = patient_search_result[0].patientid
        else:
            patient_id = False
        return patient_id

    def get_patient_by_person_id(self,person_id):
        patient_id = self.get_patient_id(person_id)
        if patient_id:
            return self.get_patient_by_id(patient_id)
        else:
            return False

    def get_patient_by_id(self, patient_id):
        query = Constant.PATIENT_DETAIL_BY_ID % patient_id
        patient_details = False
        patient_result = self.patient_db_data.get_info(query)
        for patient_information in patient_result:
            patient_details = self.get_patient_personal_detail(patient_information)
        return patient_details

    def get_patients_doctor(self, patient_id):
        return_data = False
        doctors_name =False
        query = Constant.PATIENT_TREATEMENT_DETAIL % patient_id
        patient_result = self.patient_db_data.get_info(query)
        if self.record_exists(patient_result):
            for patient_information in patient_result:
                doctors_name = self.doctor_details.get_doctors_name(patient_information.staffid)
            return_data = doctors_name
        return return_data

    def get_patients_ward(self, patient_id):
        ward_detail = []
        query = Constant.PATIENT_WARD_DETAIL % patient_id
        patient_result = self.patient_db_data.get_info(query)
        for patient_information in patient_result:
            ward_detail = self.ward_details.get_patient_room(patient_information.wardid)
        return ward_detail

    def add_new_patient(self, patient_details):
        person_type = "p"
        ward_details = {}
        person_id = self.person_detail.add_new_person(patient_details, person_type)
        if person_id:
            patient_id = "p"+str(person_id)
            try:
                ward_details["ward name"] = patient_details["ward name"]
                ward_details["room number"] = patient_details["room number"]
                query = Constant.ADD_NEW_PATIENT % (patient_details["disease"], person_id, patient_details["admitted date"], patient_id)
                insert_status = self.patient_db_data.set_info(query)
                if insert_status:
                    self.ward_details.set_patients_ward(ward_details, patient_id)
                    return True
            except Exception, e:
                ExceptionLogger.log_exception(e)
                self.person_detail.delete_person_by_id(person_id)
            else:
                self.person_detail.delete_person_by_id(person_id)
        return False

    def patient_treatement_entry_exists(self,patient_id):
        query = Constant.MAP_PATIENT_TO_DOCTOR % patient_id
        search_result = self.patient_db_data.get_info(query)
        exists = False
        if self.record_exists(search_result):
            exists = True
        return exists

    def change_patient_disease(self,person_id,disease):
        patient_id = self.get_patient_id(person_id)
        modify_status = False
        if patient_id:
            query = Constant.UPDATE_PATIENT_DISEASE % (disease, patient_id)
            modify_status = self.patient_db_data.set_info(query)
        return modify_status

    def change_patients_doctor(self, person_id, doctors_person_id):
        patient_id = self.get_patient_id(person_id)
        modify_status = False
        if patient_id:
            staff_id = self.doctor_details.get_doctors_id(doctors_person_id)
            if staff_id:
                if not self.record_exists(self.get_patients_doctor(patient_id)):
                    query = Constant.ADD_NEW_PATIENT_DOCTOR % (patient_id,staff_id)
                    modify_status = self.patient_db_data.set_info(query)
                else:
                    if self.patient_treatement_entry_exists(patient_id):
                        query = Constant.UPDATE_PATIENT_DOCTOR % (staff_id, patient_id)
                        modify_status = self.patient_db_data.set_info(query)
        return modify_status

    def change_patient_ward(self, person_id, ward_details):
        patient_id = self.get_patient_id(person_id)
        modify_status = False
        if patient_id:
            self.ward_details.delete_patient_ward(patient_id)
            modify_status = self.ward_details.set_patients_ward(ward_details, patient_id)
        return modify_status

    def delete_patient(self, person_id):
        patient_id = self.get_patient_id(person_id)
        if not patient_id:
            delete_status = False
        else:
            delete_status = self.person_detail.delete_person_by_id(person_id)
            if delete_status:
                query_delete_patient = Constant.DELETE_PATIENT % patient_id
                delete_status = self.patient_db_data.set_info(query_delete_patient)
                delete_status = delete_status and self.ward_details.delete_patient_ward(patient_id)
                delete_status = delete_status and self.delete_patient_treatement_by_patient_id(patient_id)
        return delete_status

    def delete_patient_treatement_by_patient_id(self, patient_id):
        query = Constant.DELETE_PATIENT_TREATEMENT_BY_PATIENT_ID % patient_id
        delete_status = self.patient_db_data.set_info(query)
        return delete_status
