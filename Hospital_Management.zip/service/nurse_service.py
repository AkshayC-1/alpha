from model.db_nurse import DbNurse
from person_service import PersonService
from ward_service import WardService
from query_constants import Query as constant


class NurseService:

    __instance = None

    def __init__(self):
        self.person_detail = PersonService.get_person_service_instance()
        self.nurse_db_data = DbNurse.get_db_nurse_instance()
        self.ward_detail = WardService()

    @classmethod
    def get_nurse_service_instance(cls):
        if cls.__instance is None:
            cls.__instance = NurseService()
        return cls.__instance

    def record_exists(self, search_result):
        return_status = True
        try:
            search_result[0]
        except:
            return_status = False
        return return_status

    def get_all_nurse(self):
        all_nurse_data = []
        nurse_result = self.nurse_db_data.get_info(constant.ALL_NURSE)
        for nurse_entry in nurse_result:
            person_detail = self.person_detail.search_person_by_id(nurse_entry.personid)
            person_detail["ward duties"] = self.ward_detail.get_ward_duty(nurse_entry.staffid)
            all_nurse_data.append(person_detail)
        return all_nurse_data

    def get_nurse_by_id(self,person_id):
        if self.get_staff_id(person_id):
            nurse_detail = self.person_detail.search_person_by_id(person_id)
            nurse_detail["ward duties"] = self.ward_detail.get_ward_duty(self.get_staff_id(person_id))
            return nurse_detail
        return False

    def add_new_nurse(self, nurse_details):
        person_type = 'n'
        add_status = False
        person_id = self.person_detail.add_new_person(nurse_details, person_type)
        if person_id:
            staff_id = "n" + str(person_id)
            query = constant.ADD_NEW_NURSE % (staff_id, person_id)
            add_status = self.nurse_db_data.set_info(query)
            if not add_status:
                self.person_detail.delete_person_by_id(person_id)
        return add_status

    def get_staff_id(self,person_id):
        query = constant.STAFF_ID_OF_NURSE % person_id
        nurse_detail = self.nurse_db_data.get_info(query)
        if not self.record_exists(nurse_detail):
            return_data = False
        else:
            staff_id = nurse_detail[0].staffid
            return_data = staff_id
        return return_data

    def add_ward_duty(self, person_id, ward_details):
        staff_id = self.get_staff_id(person_id)
        add_status = False
        already_exists = self.ward_detail.ward_duty_already_exists(ward_details, staff_id)
        if staff_id and (not already_exists):
            add_status = self.ward_detail.set_ward_duty(ward_details, staff_id)
        return add_status

    def delete_nurse(self, person_id):
        staff_id = self.get_staff_id(person_id)
        if not staff_id:
            delete_status = False
        else:
            delete_status = self.person_detail.delete_person_by_id(person_id)
            if delete_status:
                self.ward_detail.delete_all_ward_duty(staff_id)
                query = constant.DELETE_NURSE % staff_id
                delete_status = self.nurse_db_data.set_info(query)
        return delete_status

    def delete_ward_duty(self, person_id, ward_name, room_number):
        delete_status = False
        ward_data = {}
        staff_id = self.get_staff_id(person_id)
        if staff_id:
            ward_data["ward name"] = ward_name
            ward_data["room number"] = room_number
            delete_status = self.ward_detail.delete_ward_duty(ward_data, staff_id)
        return delete_status




