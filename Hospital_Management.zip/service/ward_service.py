from model.db_ward import DbWard
from query_constants import Query as constant
from logger.exception_logger import ExceptionLogger

class WardService:
    __instance = None

    def __init__(self):
        self.ward_db_data = DbWard()

    @classmethod
    def get_ward_service_instance(cls):
        if cls.__instance is None:
            cls.__instance = WardService()
        return cls.__instance

    def record_exists(self, search_result):
        return_status = True
        try:
            search_result[0]
        except:
            return_status = False
        return return_status

    def generate_ward_id(self):
        query = constant.MAX_WARD_ID
        ward_id = self.ward_db_data.get_info(query)
        if ward_id[0].max is not None:
            ward_id_count = ward_id[0].max + 1
        else:
            ward_id_count = 1
        return ward_id_count

    def delete_patient_ward(self, patient_id):
        query = constant.WARD_ID_OF_PATIENT % patient_id
        ward_detail = self.ward_db_data.get_info(query)
        if not self.record_exists(ward_detail):
            delete_status = False
        else:
            ward_id = ward_detail[0].wardid
            query = constant.DELETE_PATIENT_WARD % str(ward_id)
            delete_status = self.ward_db_data.set_info(query)
            if delete_status:
                delete_status = self.delete_ward(ward_id)
        return delete_status

    def delete_ward(self, ward_id):
        query = constant.DELETE_WARD_BY_ID % ward_id
        delete_status = self.ward_db_data.set_info(query)
        return delete_status

    def set_patients_ward(self, ward_detail, patient_id):
        ward_id = self.generate_ward_id()
        query = constant.ADD_NEW_WARD % (str(ward_id), ward_detail["ward name"], ward_detail["room number"])
        add_status = self.ward_db_data.set_info(query)
        if add_status:
            query = constant.ADD_NEW_PATIENT_WARD % (patient_id, str(ward_id))
            add_status = self.ward_db_data.set_info(query)
            if not add_status:
                self.delete_ward(ward_id)
        return add_status

    def delete_all_ward_duty(self, staffid):
        ward_delete_status = True
        query = constant.WARD_DUTY_ID % staffid
        ward_result = self.ward_db_data.get_info(query)
        if self.record_exists(ward_result):
            for ward_id_detail in ward_result:
                ward_delete_status = ward_delete_status and self.delete_ward(ward_id_detail.wardid)
            query = constant.DELETE_WARD_DUTY % staffid
            ward_delete_status = ward_delete_status and self.ward_db_data.set_info(query)
        else:
            ward_delete_status = False
        return ward_delete_status

    def delete_ward_duty(self, ward_detail, staff_id):
        delete_status = False
        query = constant.WARD_DUTY_ID % staff_id
        ward_data = self.ward_db_data.get_info(query)
        for ward_id in ward_data:
            query = constant.WARD_ID_BY_WARD_DETAILS % (ward_id.wardid, ward_detail["ward name"], ward_detail["room number"])
            if self.record_exists(self.ward_db_data.get_info(query)):
                query = constant.DELETE_WARD_BY_ID % str(ward_id.wardid)
                delete_status = self.ward_db_data.set_info(query)
                if delete_status:
                    delete_status = delete_status and self.delete_ward(ward_id)
                break
        return delete_status

    def set_ward_duty(self, ward_detail, staff_id):
        ward_id = self.generate_ward_id()
        query = constant.ADD_NEW_WARD % (str(ward_id), ward_detail["ward name"], ward_detail["room number"])
        add_status = self.ward_db_data.set_info(query)
        if add_status:
            query = constant.ADD_NEW_WARD_DUTY % (staff_id, str(ward_id))
            add_status = self.ward_db_data.set_info(query)
            if not add_status:
                self.delete_ward(ward_id)
        return add_status

    def get_ward_duty(self, staff_id):
        ward_collection = []
        ward = {}
        query = constant.WARD_DUTY_ID % staff_id
        ward_data = self.ward_db_data.get_info(query)
        if self.record_exists(ward_data):
            for ward_id in ward_data:
                query = constant.WARD_DETAIL_BY_ID % ward_id.wardid
                ward_detail = self.ward_db_data.get_info(query)
                for room_detail in ward_detail:
                    ward["ward name"] = room_detail.wardname
                    ward["room number"] = room_detail.roomnumber
                    ward_collection.append(ward.copy())
        return ward_collection

    def get_patient_room(self, patient_id):
        ward = {}
        query = constant.WARD_ID_OF_PATIENT % patient_id
        ward_data = self.ward_db_data.get_info(query)
        if self.record_exists(ward_data):
            query = constant.WARD_DETAIL_BY_ID % ward_data[0].wardid
            ward_detail = self.ward_db_data.get_info(query)
            if self.record_exists(ward_detail):
                ward["ward name"] = ward_detail[0].wardname
                ward["room number"] = ward_detail[0].roomnumber
        return ward

    def ward_duty_already_exists(self, ward_details, staff_id):
        ward_records = self.get_ward_id(ward_details)
        if ward_records is not False:
            for ward_data in ward_records:
                query = constant.WARD_DUTY_OF_STAFF % (ward_data.wardid, staff_id)
                search_result = self.ward_db_data.get_info(query)
                if self.record_exists(search_result):
                    return True
        return False

    def get_ward_id(self, ward_details):
        query = constant.WARD_ID_OF_WARD % (ward_details["ward name"], ward_details["room number"])
        ward_records = self.ward_db_data.get_info(query)
        status = self.record_exists(ward_records)
        if status:
            return ward_records
        return status
