from model.db_person import DbPerson
from query_constants import Query as constant
from logger.exception_logger import ExceptionLogger

class PersonService:
    __instance = None

    def __init__(self):
        self.person_db_operation = DbPerson.get_db_person_instance()
        self.person_db_operation = DbPerson.get_db_person_instance()

    @classmethod
    def get_person_service_instance(cls):
        if cls.__instance is None:
            cls.__instance = PersonService()
        return cls.__instance

    def set_other_instance(self, patient_instance, doctor_instance, nurse_instance):
        self.patient_details = patient_instance
        self.doctor_details = doctor_instance
        self.nurse_details = nurse_instance

    def get_person_detail(self, person_id):
        query = constant.PERSON_DETAIL_BY_ID % str(person_id)
        person_entry = self.person_db_operation.get_info(query)
        return person_entry

    def search_person_by_id(self, person_id):
        person_information = {}
        person_entry = self.get_person_detail(person_id)
        for person_detail in person_entry:
            person_information["Name"] = person_detail.name
            person_information["age"] = person_detail.age
            person_information["Date of birth"] = str(person_detail.dateofbirth)
            person_information["gender"] = person_detail.gender
            person_information["Contact Number"] = person_detail.contactnumber
        return person_information

    def add_new_user(self, user_details):
        if user_details["user type"] is None:
            return False
        else:
            user_type = user_details["user type"]
            if user_type == "patient":
                add_status = self.patient_details.add_new_patient(user_details)
            elif user_type == 'doctor':
                add_status = self.doctor_details.add_new_doctor(user_details)
            elif user_type == 'nurse':
                add_status = self.nurse_details.add_new_nurse(user_details)
            else:
                add_status = False
        return add_status

    def record_exists(self, search_result):
        return_status = True
        try:
            search_result[0]
        except:
            return_status = False
        return return_status

    def get_person_type(self, person_id):
        person_type = False
        person_entry = self.get_person_detail(person_id)
        if self.person_exists(person_entry):
            person_type = person_entry[0].personType
        return person_type

    def generate_person_id(self):
        query = constant.MAX_PERSON_ID
        search_result = self.person_db_operation.get_info(query)
        if search_result[0].max is not None:
            return search_result[0].max+1
        else:
            return 1

    def add_new_person(self,person_details, person_type):
        person_id = self.generate_person_id()
        try:
            query_to_add_new_person = constant.ADD_NEW_PERSON % (str(person_id),person_details["name"],person_details["date of birth"],person_details["age"],person_details["contact number"],person_details["gender"],person_type)
        except Exception, e:
            ExceptionLogger.log_exception(e)
            return False
        status = self.person_db_operation.set_info(query_to_add_new_person)
        if status:
            return person_id
        return status

    def person_exists(self, person_search_result):
        exists = True
        try:
            person_search_result[0]
        except:
            exists = False
        return exists

    def delete_person(self, person_id):
        query = constant.DELETE_PERSON_BY_ID % person_id
        return self.person_db_operation.set_info(query)

    def delete_person_by_id(self, person_id):
        query = constant.PERSON_DETAIL_BY_ID % str(person_id)
        person_search_result = self.person_db_operation.get_info(query)
        exists = self.person_exists(person_search_result)
        delete_status = True
        if exists:
            delete_status = self.delete_person(person_id)
        else:
            delete_status = False
        return delete_status







