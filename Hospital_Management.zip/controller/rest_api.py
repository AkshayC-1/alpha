from flask import Flask
from flask import request,Response
import json
from person_service import PersonService
from patient_service import PatientService
from doctor_service import DoctorService
from nurse_service import NurseService
# from ward_service import WardService
# from json_data import FormatData

application = Flask(__name__)


@application.route("/hms/users", methods=['GET'])
def get_all_user_detail():
    if request.args.get("type") is None:
        result_patient = {"patient": patient_operations.get_all_patient()}
        result_doctor = {"doctor": doctor_operations.get_all_doctor()}
        result_nurse = {"nurse": nurse_operations.get_all_nurse()}
        return json.dumps([result_patient, result_doctor, result_nurse])
    else:
        return get_user_specific_detail()


@application.route("/hms/users", methods=['GET'])
def get_user_specific_detail():
    person_type = request.args.get("type")
    if request.args.get("personid") is None:
        if person_type == 'patient':
            return_data = {"patient": patient_operations.get_patient_data(request.args)}
        elif person_type == 'doctor':
            return_data = {"doctor": doctor_operations.get_doctor_data(request.args)}
        elif person_type == 'nurse':
            return_data = {"nurse": nurse_operations.get_nurse_data(request.args)}
        else:
            return Response("INVALID REQUEST", status=400)
    return json.dumps(return_data)


@application.route("/hms/users", methods=['POST'])
def new_user():
    if request.is_json:
        user_details = request.get_json()
        status = person_operations.add_new_user(user_details)
    return json.dumps(status)


@application.route("/hms/user/<person_id>", methods=['DELETE'])
def delete_user(person_id):
    person_type = person_operations.get_person_type(person_id)
    if not person_type:
        status = False
        status_code = 404
    else:
        if person_type == 'p':
            status = patient_operations.delete_patient(person_id)
        elif person_type == 'd':
            status = doctor_operations.delete_doctor(person_id)
        elif person_type == 'n':
            status = nurse_operations.delete_nurse(person_id)
    return Response(json.dumps(status))


if __name__ == '__main__':
    patient_operations = PatientService()
    doctor_operations = DoctorService()
    nurse_operations = NurseService()
    person_operations = PersonService([patient_operations, doctor_operations, nurse_operations])
    # ward_operations = WardService()
    # convert_data = FormatData()
    application.run()
