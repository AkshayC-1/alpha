import logging


class ExceptionLogger:
    instance = None

    def __init__(self):
        log_file = 'exceptionLog.log'
        logging.basicConfig(filename=log_file)

    @classmethod
    def create_logger_instance(cls):
        cls.instance = ExceptionLogger()

    @classmethod
    def log_exception(cls, ex):
        if cls.instance is None:
            cls.create_logger_instance()
        logging.exception(ex.message)

