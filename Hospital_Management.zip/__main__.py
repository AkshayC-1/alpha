from flask import Flask
from flask import request,Response
import json
from service.person_service import PersonService
from service.patient_service import PatientService
from service.doctor_service import DoctorService
from service.nurse_service import NurseService
from view.person_data import PersonReturnData
from view.patient_data import PatientReturnData
from view.doctor_data import DoctorReturnData
from view.nurse_data import NurseReturnData
from model.auth_user import Authenticator
from basicauth import decode
from logger.exception_logger import ExceptionLogger
from model.token_generator import TokenGenerator
from view.token_response import TokenResponse
import base64
application = Flask(__name__)


def user_auth():
    try:
        token_header = request.headers["authorization"]
        _, token_string = token_header.split(" ")
        status = authentication.verify_token(base64.b64decode(token_string))
        # username, password = decode(request.headers["Authorization"])
        # credential = {'username': username, 'password': password}
        # status = authentication.verify_auth(credential)

    except Exception, e:
        ExceptionLogger.log_exception(e)
        status = False
    return status


def invalid_cred_message():
    return Response(json.dumps({"status":"Invalid Credentials"}),status=401)


@application.route("/hms/users", methods=['GET'])
def get_all_user_detail():
    if user_auth():
        if request.args.get("type") is None:
            result_patient = {"patient": patient_operations.get_all_patient()}
            result_doctor = {"doctor": doctor_operations.get_all_doctor()}
            result_nurse = {"nurse": nurse_operations.get_all_nurse()}
            return Response(json.dumps([result_patient, result_doctor, result_nurse]), status=200)
        else:
            return get_user_specific_detail()
    else:
        return invalid_cred_message()


@application.route("/hms", methods=['GET','POST','PUT','DELETE'])
def no_method_hsm():
    response = json.dumps({'status': 'Method Not Allowed'})
    return Response(response, status=405)


@application.route("/hms/users", methods=['DELETE'])
def no_delete_method_users():
    response = json.dumps({'status': 'Method Not Allowed'})
    return Response(response, status=405)


@application.route("/hms/users", methods=['GET'])
def get_user_specific_detail():
    if user_auth():
        person_type = request.args.get("type")
        if request.args.get("personid") is None:
            if person_type == 'patient':
                return_data = {"patient": patient_operations.get_patient_data()}
            elif person_type == 'doctor':
                return_data = {"doctor": doctor_operations.get_all_doctor()}
            elif person_type == 'nurse':
                return_data = {"nurse": nurse_operations.get_all_nurse()}
            else:
                return Response(json.dumps({'status': 'INVALID REQUEST'}), status=400)
        else:
            if person_type == 'patient':
                return_data = {"patient": patient_operations.get_patient_by_person_id(request.args.get("personid"))}
            elif person_type == 'doctor':
                return_data = {"doctor": doctor_operations.get_doctor_by_id(request.args.get("personid"))}
            elif person_type == 'nurse':
                return_data = {"nurse": nurse_operations.get_nurse_by_id(request.args.get("personid"))}
            else:
                return Response(json.dumps({'status': 'INVALID REQUEST'}), status=400)
        return person_view.person_search(return_data, person_type)
    else:
        return invalid_cred_message()


@application.route("/hms/users", methods=['POST'])
def new_user():
    if user_auth():
        status = False
        if request.is_json:
            user_details = request.get_json()
            status = person_operations.add_new_user(user_details)
        response = person_view.new_user(status)
        return Response(response['status'], response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/<person_id>", methods=['DELETE'])
def delete_user(person_id):
    if user_auth():
        status = False
        person_type = person_operations.get_person_type(person_id)
        if not person_type:
            status = False
        else:
            if person_type == 'p':
                status = patient_operations.delete_patient(person_id)
            elif person_type == 'd':
                status = doctor_operations.delete_doctor(person_id)
            elif person_type == 'n':
                status = nurse_operations.delete_nurse(person_id)
        response = person_view.delete_user(status)
        return Response(response['status'], status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/patients/diseases", methods=["PUT"])
def modify_patient_disease():
    if user_auth():
        modify_status = False
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id_status = user_details["person id"] is not None
                disease_status = user_details["disease"] is not None
                if person_id_status and disease_status:
                    modify_status = patient_operations.change_patient_disease(user_details["person id"],user_details["disease"])
                response = patient_view.patient_modify(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'],status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/patients/doctors", methods=["PUT"])
def modify_patients_doctor():
    if user_auth():
        modify_status = False
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id_status = user_details["patients person id"] is not None
                doctors_id_status = user_details["doctors person id"] is not None
                if person_id_status and doctors_id_status:
                    modify_status = patient_operations.change_patients_doctor(user_details["patients person id"], user_details["doctors person id"])
                response = patient_view.patient_modify(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'], status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/patients/wards", methods=["PUT"])
def modify_patient_ward():
    if user_auth():
        modify_status = False
        ward_details = {}
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id_status = user_details["person id"] is not None
                ward_name_status = user_details["ward name"] is not None
                room_number_status = user_details["room number"] is not None
                if person_id_status and ward_name_status and room_number_status:
                    ward_details["ward name"] = user_details["ward name"]
                    ward_details["room number"] = user_details["room number"]
                    modify_status = patient_operations.change_patient_ward(user_details["person id"], ward_details)
                response = patient_view.patient_modify(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'], status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/doctors/specializations", methods=["PUT"])
def modify_doctor_specialization():
    if user_auth():
        modify_status = False
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id_status = user_details["person id"] is not None
                specialization_status = user_details["specialization"] is not None
                if person_id_status and specialization_status:
                    modify_status = doctor_operations.change_specialization(user_details["person id"], user_details["specialization"])
                response = doctor_view.doctor_modify(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'], status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/nurses/ward-duties", methods=["PUT"])
def modify_nurses_ward():
    if user_auth():
        modify_status = False
        ward_details = {}
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id_status = user_details["person id"] is not None
                ward_name_status = user_details["ward name"] is not None
                room_number_status = user_details["room number"] is not None
                if person_id_status and ward_name_status and room_number_status:
                    ward_details["ward name"] = user_details["ward name"]
                    ward_details["room number"] = user_details["room number"]
                    modify_status = nurse_operations.add_ward_duty(user_details["person id"], ward_details)
                response = nurse_view.nurse_modify(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'],status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/hms/users/nurses/ward-duties", methods=["DELETE"])
def delete_nurse_ward_duty():
    if user_auth():
        if request.is_json:
            user_details = request.get_json()
            try:
                person_id = user_details["person id"]
                ward_name = user_details["ward name"]
                room_number = user_details["room number"]
                modify_status = nurse_operations.delete_ward_duty(person_id, ward_name, room_number)
                response = nurse_view.delete_ward(modify_status)
            except Exception, e:
                ExceptionLogger.log_exception(e)
                response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        else:
            response = {'status': json.dumps({"status": "Invalid Request"}), 'status code': "400"}
        return Response(response['status'], status=response['status code'])
    else:
        return invalid_cred_message()


@application.route("/tokens", methods=["POST"])
def get_new_token():
    token = False
    try:
        username, password = decode(request.headers["authorization"])
        credential = {'username': username, 'password': password}
        token = generate_token.validate_client(credential)
    except Exception, e:
        ExceptionLogger.log_exception(e)
        return invalid_cred_message()
    return TokenResponse.return_token(token)


if __name__ == '__main__':
    patient_operations = PatientService.get_patient_service_instance()
    doctor_operations = DoctorService.get_doctor_service_instance()
    nurse_operations = NurseService.get_nurse_service_instance()
    person_view = PersonReturnData()
    doctor_view = DoctorReturnData()
    patient_view = PatientReturnData()
    nurse_view = NurseReturnData()
    person_operations = PersonService.get_person_service_instance()
    person_operations.set_other_instance(patient_operations, doctor_operations, nurse_operations)
    authentication = Authenticator()
    generate_token = TokenGenerator()
    application.run()
