from cassandra.cluster import Cluster
import hashlib
import logging
import sys
import datetime

class Authenticator:

    def __init__(self):
        try:
            log_file = 'exceptionLog.log'
            logging.basicConfig(filename=log_file)
            connection = Cluster()
            self.query = connection.connect("admin")
        except Exception, e:
            logging.exception(e.message)
            logging.exception("\n\n")
            print "Server could not start.Application now closing"
            sys.exit(0)



    def record_exists(self, result):
        status = True
        try:
            result[0]
        except Exception:
            status = False
        return status

    def verify_auth(self, credential):
        authenticated = False
        hash_key = credential['username']+':'+credential['password']
        credential_hash = hashlib.sha1(hash_key).hexdigest()
        query_statement = "select * from authentication where credential = '%s'" % credential_hash
        auth_result = self.query.execute(query_statement)
        if self.record_exists(auth_result):
            authenticated = True
        return authenticated

    @staticmethod
    def check_date_validity(year, month, day, hour, minute, current_datetime):
        if current_datetime.year <= year:
            if current_datetime.month <= month:
                if current_datetime.day < day:
                    return True
                elif current_datetime.day == day:
                    return Authenticator.check_time_validity(hour, minute, current_datetime)
        return False

    @staticmethod
    def check_time_validity(hour, minute, current_datetime):
        if current_datetime.hour < hour:
            return True
        elif current_datetime.hour == hour:
            if current_datetime.minute < minute:
                return True
        return False

    def verify_token(self, token):
        query_statement = "select * from token_data where token_string = '%s' ALLOW FILTERING" % token
        search_result = self.query.execute(query_statement)
        if not self.record_exists(search_result):
            return False
        else:
            current_datetime = datetime.datetime.now()
            expiry_date = str(search_result[0].expiry_date)
            expiry_time = str(search_result[0].expiry_time)
            [year, month, day] = map(int, expiry_date.split("-"))
            [hour, minute, _] = expiry_time.split(":")
            hour = int(hour)
            minute = int(minute)
            if Authenticator.check_date_validity(year, month, day, hour, minute,current_datetime):
                return True
            query_statement = "delete from token_data where token_string = '%s'" % token
            self.query.execute(query_statement)
            return False






