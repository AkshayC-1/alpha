from cassandra.cluster import Cluster
from logger.exception_logger import ExceptionLogger
import sys
import string
from random import choice,randint
import datetime
import base64

class TokenGenerator:
    def __init__(self):
        try:
            connection = Cluster()
            self.query = connection.connect("admin")
        except Exception, e:
            ExceptionLogger.log_exception(e.message)
            print "Server could not start.Application now closing"
            sys.exit(0)

    def record_exists(self,record):
        status = True
        try:
            record[0]
        except:
            status = False
        return status

    @staticmethod
    def get_token_expiry():
        current_datetime = datetime.datetime.now()
        expiry_datetime = current_datetime + datetime.timedelta(minutes=10)
        month = "%02d" % expiry_datetime.month
        day = "%02d" % expiry_datetime.day
        hour = "%02d" % expiry_datetime.hour
        minute = "%02d" % expiry_datetime.minute
        seconds = "00"
        date = str(expiry_datetime.year) + '-' + month + '-' + day
        time = hour + ':' + minute + ':' + seconds
        expiry = {"date": date, "time": time}
        return expiry

    def get_token(self,user_id):
        min_char = 8
        max_char = 10
        char_set = string.ascii_letters + string.digits
        while True:
            token_string = "".join(choice(char_set) for x in range(randint(min_char, max_char)))
            query_statement = "select token_string from token_data where token_string = '%s' ALLOW FILTERING" % token_string
            query_result = self.query.execute(query_statement)
            if not self.record_exists(query_result):
                break
        date_time = TokenGenerator.get_token_expiry()
        query_statement = "insert into token_data(token_string,expiry_time,expiry_date,user_id) values('%s','%s','%s',%s)" % (token_string, date_time["time"], date_time["date"],user_id)
        try:
            self.query.execute(query_statement)
        except Exception, e:
            ExceptionLogger.log_exception(e)
            return False
        encode_token_string = base64.b64encode(token_string)
        return encode_token_string

    def validate_client(self, user_credential):
        query_statement = "select * from user where username = '%s' and password = '%s' ALLOW FILTERING" % (user_credential['username'],user_credential['password'])
        search_result = self.query.execute(query_statement)
        token = False
        if self.record_exists(search_result):
            query_statement = "select user_id from user where username = '%s' and password = '%s' ALLOW FILTERING" % (user_credential['username'],user_credential['password'])
            search_result = self.query.execute(query_statement)
            if self.record_exists(search_result):
                user_id = search_result[0].user_id
                token = self.get_token(user_id)
        return token



