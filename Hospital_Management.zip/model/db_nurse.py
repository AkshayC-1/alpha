from cassandra.cluster import Cluster
import logging, sys


class DbNurse:

    _instance = None
    def __init__(self):
        try:
            log_file = 'exceptionLog.log'
            logging.basicConfig(filename=log_file)
            connection = Cluster()
            self.query = connection.connect("hospital")
        except Exception, e:
            logging.exception(e.message)
            logging.exception("\n\n")
            print "Server could not start. Application now closing"
            sys.exit(0)

    @classmethod
    def get_db_nurse_instance(cls):
        if cls._instance is None:
            cls._instance = DbNurse()
        return cls._instance

    def get_info(self, query_statement):
        search_result = self.query.execute(query_statement)
        return search_result

    def set_info(self, query_statement):
        status = True
        try:
            self.query.execute(query_statement)
        except Exception, e:
            logging.log(e)
        return status
